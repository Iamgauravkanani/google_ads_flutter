package com.example.google_ads_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
